import 'dart:async';
import 'dart:convert';
import 'dart:io';

import '../data/reminder.dart';
import 'assistant_parser.dart';

class GeminiException implements Exception {
  GeminiException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Turns a spoken command into a [ReminderDraft] using the Gemini API.
/// Throws [GeminiException] on any failure so the caller can fall back to
/// the offline [UzbekCommandParser].
class GeminiCommandParser {
  static const _weekdayNames = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  static String _two(int value) => value.toString().padLeft(2, '0');

  static String _systemPrompt(DateTime now) {
    final stamp =
        '${now.year}-${_two(now.month)}-${_two(now.day)} ${_two(now.hour)}:${_two(now.minute)}';
    return 'You convert one spoken reminder command into JSON. '
        'The speaker usually speaks Uzbek (Latin script), sometimes Russian or English. '
        'The text comes from speech recognition and may contain small mistakes.\n\n'
        'Current local date and time: $stamp (${_weekdayNames[now.weekday - 1]}).\n\n'
        'Rules:\n'
        '- "date" is YYYY-MM-DD and "time" is 24-hour HH:MM.\n'
        '- Uzbek day parts: "ertalab" = morning, "tushda" or "peshinda" = around 12-13, '
        '"tushdan keyin" = afternoon, "kechqurun" or "kechasi" = evening or night. '
        'Use 24-hour time, for example "kechqurun soat sakkizda" = 20:00.\n'
        '- "yarim" means half past: "soat sakkiz yarimda" = 08:30 (20:30 in the evening).\n'
        '- "bugun" = today, "ertaga" = tomorrow, "indinga" = day after tomorrow.\n'
        '- If no date is given, use today if the time is still ahead, otherwise tomorrow.\n'
        '- If no time is given, use 09:00.\n'
        '- "recurrence" is one of none, daily, weekly, monthly. '
        '"har kuni" = daily, "har hafta" or "har <weekday>" = weekly, "har oy" = monthly, otherwise none.\n'
        '- "weekdays" uses 1=Monday ... 7=Sunday and is only used for weekly recurrence.\n'
        '- "title" is a short task name in the speaker\'s language without the date or time words. '
        'Keep names and capital letters as spoken. Do not add the word "reminder".\n'
        '- "description" is empty unless the speaker gave extra details.\n';
  }

  static Future<ReminderDraft> parse({
    required String text,
    required String apiKey,
    required String model,
    DateTime? now,
  }) async {
    final key = apiKey.trim();
    if (key.isEmpty) throw GeminiException('Gemini kaliti kiritilmagan');
    final current = now ?? DateTime.now();
    final modelName = model.trim().isEmpty
        ? 'gemini-flash-lite-latest'
        : model.trim();

    final body = {
      'systemInstruction': {
        'parts': [
          {'text': _systemPrompt(current)},
        ],
      },
      'contents': [
        {
          'role': 'user',
          'parts': [
            {'text': text},
          ],
        },
      ],
      'generationConfig': {
        'temperature': 0,
        'responseMimeType': 'application/json',
        'responseSchema': {
          'type': 'OBJECT',
          'properties': {
            'title': {'type': 'STRING'},
            'description': {'type': 'STRING'},
            'date': {'type': 'STRING'},
            'time': {'type': 'STRING'},
            'recurrence': {
              'type': 'STRING',
              'enum': ['none', 'daily', 'weekly', 'monthly'],
            },
            'weekdays': {
              'type': 'ARRAY',
              'items': {'type': 'INTEGER'},
            },
          },
          'required': ['title', 'date', 'time', 'recurrence'],
        },
      },
    };

    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 8);
    try {
      final uri = Uri.https(
        'generativelanguage.googleapis.com',
        '/v1beta/models/$modelName:generateContent',
      );
      final request = await client.postUrl(uri);
      request.headers.contentType = ContentType.json;
      request.headers.set('x-goog-api-key', key);
      request.add(utf8.encode(jsonEncode(body)));
      final response = await request.close().timeout(
        const Duration(seconds: 20),
      );
      final raw = await response
          .transform(utf8.decoder)
          .join()
          .timeout(const Duration(seconds: 20));
      if (response.statusCode != 200) {
        throw GeminiException(
          'Gemini xatosi ${response.statusCode}: ${_errorMessage(raw)}',
        );
      }
      return _toDraft(raw);
    } on GeminiException {
      rethrow;
    } on TimeoutException {
      throw GeminiException('Gemini javob bermadi (vaqt tugadi)');
    } on SocketException {
      throw GeminiException('Internet yo‘q');
    } on HandshakeException {
      throw GeminiException('Xavfsiz ulanish o‘rnatilmadi');
    } on FormatException {
      throw GeminiException('Gemini javobini o‘qib bo‘lmadi');
    } finally {
      client.close(force: true);
    }
  }

  static String _errorMessage(String raw) {
    try {
      final data = jsonDecode(raw);
      final error = (data as Map)['error'];
      final message = error is Map ? error['message'] : null;
      if (message is String && message.isNotEmpty) {
        return message.length > 160 ? '${message.substring(0, 160)}…' : message;
      }
    } catch (_) {}
    return 'noma‘lum xato';
  }

  static ReminderDraft _toDraft(String raw) {
    final root = jsonDecode(raw);
    final candidates = (root as Map)['candidates'];
    if (candidates is! List || candidates.isEmpty) {
      throw GeminiException('Gemini javob bermadi');
    }
    final content = (candidates.first as Map)['content'];
    final parts = content is Map ? content['parts'] : null;
    if (parts is! List || parts.isEmpty) {
      throw GeminiException('Gemini bo‘sh javob qaytardi');
    }
    final text = parts.map((part) => (part as Map)['text'] ?? '').join();
    final data = jsonDecode(text);
    if (data is! Map) throw GeminiException('Gemini javobi noto‘g‘ri');

    final date = RegExp(
      r'^(\d{4})-(\d{1,2})-(\d{1,2})$',
    ).firstMatch((data['date'] as String? ?? '').trim());
    final time = RegExp(
      r'^(\d{1,2}):(\d{2})$',
    ).firstMatch((data['time'] as String? ?? '').trim());
    if (date == null || time == null) {
      throw GeminiException('Gemini sana yoki vaqtni aniqlay olmadi');
    }
    final year = int.parse(date.group(1)!);
    final month = int.parse(date.group(2)!);
    final day = int.parse(date.group(3)!);
    final hour = int.parse(time.group(1)!);
    final minute = int.parse(time.group(2)!);
    if (month < 1 ||
        month > 12 ||
        day < 1 ||
        day > 31 ||
        hour > 23 ||
        minute > 59) {
      throw GeminiException('Gemini noto‘g‘ri sana yoki vaqt qaytardi');
    }
    final dueAt = DateTime(year, month, day, hour, minute);

    final recurrence = ReminderRecurrence.values.firstWhere(
      (value) => value.name == data['recurrence'],
      orElse: () => ReminderRecurrence.none,
    );
    var weekdays = <int>[];
    if (recurrence == ReminderRecurrence.weekly) {
      final rawDays = data['weekdays'];
      if (rawDays is List) {
        weekdays = rawDays
            .whereType<num>()
            .map((value) => value.toInt())
            .where((value) => value >= 1 && value <= 7)
            .toSet()
            .toList();
        weekdays.sort();
      }
      if (weekdays.isEmpty) weekdays = [dueAt.weekday];
    }

    final title = (data['title'] as String? ?? '').trim();
    final description = (data['description'] as String? ?? '').trim();
    return ReminderDraft(
      title: title.length > 120 ? title.substring(0, 120) : title,
      description: description,
      dueAt: dueAt,
      recurrence: recurrence,
      weekdays: weekdays,
      isCertain: true,
      explanation: 'Gemini yordamida tahlil qilindi.',
    );
  }
}
