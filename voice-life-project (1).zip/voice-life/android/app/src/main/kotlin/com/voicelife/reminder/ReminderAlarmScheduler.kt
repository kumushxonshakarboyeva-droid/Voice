package com.voicelife.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

class ReminderAlarmScheduler(private val context: Context) {
    private val alarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExactAlarms(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    fun schedule(reminder: Map<String, Any?>) {
        val id = reminder["id"]?.toString() ?: return
        val status = reminder["status"]?.toString()
        val recurring = reminder["recurrence"]?.toString() != "none"
        if (status != "pending" && !(recurring && status in setOf("ringing", "snoozed"))) {
            return
        }
        cancelMain(id)
        val triggerAt = (reminder["dueAtMs"] as? Number)?.toLong() ?: return
        val pendingIntent = alarmPendingIntent(id, snoozed = false)
        setAlarm(triggerAt, pendingIntent)
    }

    fun scheduleSnooze(id: String, at: Long) {
        cancelSnooze(id)
        val pendingIntent = alarmPendingIntent(id, snoozed = true)
        setAlarm(at, pendingIntent)
    }

    fun cancelMain(id: String) {
        alarmManager.cancel(alarmPendingIntent(id, snoozed = false))
    }

    fun cancelSnooze(id: String) {
        alarmManager.cancel(alarmPendingIntent(id, snoozed = true))
    }

    fun cancelAllAndReschedule(recoverRinging: Boolean = false) {
        val database = ReminderDatabase.get(context)
        database.markLongOverdue()
        database.listReminders().forEach { reminder ->
            val id = reminder["id"]?.toString() ?: return@forEach
            cancelMain(id)
            cancelSnooze(id)
            when (reminder["status"]?.toString()) {
                "pending" -> schedule(reminder)
                "snoozed" -> {
                    val snoozedUntil = (reminder["snoozedUntilMs"] as? Number)?.toLong()
                    if (snoozedUntil != null && snoozedUntil > System.currentTimeMillis()) {
                        scheduleSnooze(id, snoozedUntil)
                    } else {
                        scheduleSnooze(id, System.currentTimeMillis() + 5_000)
                    }
                    if (reminder["recurrence"] != "none") schedule(reminder)
                }
                "ringing" -> {
                    if (reminder["recurrence"] != "none") {
                        schedule(reminder)
                    } else if (recoverRinging) {
                        scheduleSnooze(id, System.currentTimeMillis() + 5_000)
                    }
                }
            }
        }
    }

    fun exactAlarmSettingsIntent(): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || canScheduleExactAlarms()) {
            return null
        }
        return Intent(
            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
            Uri.parse("package:${context.packageName}"),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private fun setAlarm(at: Long, pendingIntent: PendingIntent) {
        val triggerAt = at.coerceAtLeast(System.currentTimeMillis() + 1000)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            return
        }
        try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAt,
                pendingIntent,
            )
        } catch (error: SecurityException) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) throw error
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    private fun alarmPendingIntent(id: String, snoozed: Boolean): PendingIntent {
        val intent = Intent(context, ReminderAlarmReceiver::class.java).apply {
            action = ReminderAlarmReceiver.ACTION_FIRE
            data = Uri.parse("voicelife://reminder/$id/${if (snoozed) "snooze" else "main"}")
            putExtra(ReminderAlarmReceiver.EXTRA_REMINDER_ID, id)
            putExtra(ReminderAlarmReceiver.EXTRA_SNOOZED, snoozed)
        }
        val requestCode = (id.hashCode() and 0x3fffffff) + if (snoozed) 0x40000000 else 0
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
