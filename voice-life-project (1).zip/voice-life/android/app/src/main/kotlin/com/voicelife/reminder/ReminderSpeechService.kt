package com.voicelife.reminder

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.content.pm.ServiceInfo
import java.util.ArrayDeque
import java.util.Locale

class ReminderSpeechService : Service(), TextToSpeech.OnInitListener {
    private data class SpeechItem(
        val id: String,
        val title: String,
        val text: String,
        val isPreview: Boolean = false,
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<SpeechItem>()
    private var textToSpeech: TextToSpeech? = null
    private var engineReady = false
    private var ttsInitStarted = false
    private var current: SpeechItem? = null
    private var repeatIndex = 0
    private var currentUtteranceId: String? = null
    private var foreground = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        ReminderNotifications.ensureChannel(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        @Suppress("DEPRECATION")
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:spoken-reminder")
            .apply { setReferenceCounted(false) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val startIntent = intent ?: return stopWithNoWork(startId)
        val item = when (startIntent.action) {
            ACTION_SPEAK -> {
                val id = startIntent.getStringExtra(EXTRA_REMINDER_ID)
                    ?: return stopWithNoWork(startId)
                val reminder = ReminderDatabase.get(this).getReminder(id)
                    ?: return stopWithNoWork(startId)
                val title = reminder["title"]?.toString().orEmpty()
                val description = reminder["description"]?.toString().orEmpty()
                val text = if (description.isBlank()) title else "$title. $description"
                SpeechItem(id, title, text)
            }
            ACTION_PREVIEW -> {
                val text = startIntent.getStringExtra(EXTRA_PREVIEW_TEXT)
                    ?.trim()
                    ?.take(1000)
                    ?.takeIf { it.isNotEmpty() }
                    ?: return stopWithNoWork(startId)
                SpeechItem(
                    PREVIEW_ID,
                    getString(R.string.tts_preview_title),
                    text,
                    isPreview = true,
                )
            }
            else -> return stopWithNoWork(startId)
        }
        if (current?.id == item.id || queue.any { it.id == item.id }) {
            return START_NOT_STICKY
        }
        if (current == null) {
            current = item
            enterForeground(item)
            acquireWakeLock()
            initializeTtsAfterForeground()
            if (engineReady) speakCurrent()
        } else {
            queue.addLast(item)
            if (item.isPreview) {
                ReminderNotifications.showPreview(this, item.text)
            } else {
                ReminderNotifications.showReminder(this, item.id, item.title, item.text)
            }
        }
        return START_NOT_STICKY
    }

    private fun stopWithNoWork(startId: Int): Int {
        stopSelf(startId)
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        engineReady = status == TextToSpeech.SUCCESS
        if (!engineReady) {
            failQueuedSpeech()
            return
        }
        textToSpeech?.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
        )
        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                mainHandler.post {
                    if (utteranceId == currentUtteranceId) onSpeechDone()
                }
            }

            @Deprecated("Deprecated by Android")
            override fun onError(utteranceId: String?) {
                mainHandler.post {
                    if (utteranceId == currentUtteranceId) onSpeechError()
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                mainHandler.post {
                    if (utteranceId == currentUtteranceId) onSpeechError()
                }
            }
        })
        if (current != null) speakCurrent()
    }

    override fun onDestroy() {
        instance = null
        mainHandler.removeCallbacksAndMessages(null)
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        abandonAudioFocus()
        releaseWakeLock()
        super.onDestroy()
    }

    private fun enterForeground(item: SpeechItem) {
        val notification = if (item.isPreview) {
            ReminderNotifications.buildPreview(this, item.text, ongoing = true)
        } else {
            ReminderNotifications.buildReminder(
                this,
                item.id,
                item.title,
                item.text,
                ongoing = true,
            )
        }
        val notificationId = if (item.isPreview) {
            ReminderNotifications.PREVIEW_NOTIFICATION_ID
        } else {
            ReminderNotifications.notificationId(item.id)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                notificationId,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
            )
        } else {
            startForeground(notificationId, notification)
        }
        foreground = true
    }

    private fun initializeTtsAfterForeground() {
        if (ttsInitStarted) return
        ttsInitStarted = true
        try {
            textToSpeech = TextToSpeech(applicationContext, this)
        } catch (_: Exception) {
            failQueuedSpeech()
        }
    }

    private fun speakCurrent() {
        val item = current ?: return
        val tts = textToSpeech ?: return
        val settings = ReminderDatabase.get(this).getSettings()
        val localeTag = settings["speechLocale"]?.toString() ?: "uz-UZ"
        val locale = Locale.forLanguageTag(localeTag)
        val matchingVoices = (tts.voices ?: emptySet()).filter { voice ->
            voice.locale.language.equals(locale.language, ignoreCase = true) &&
                !voice.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
        if (matchingVoices.isEmpty()) {
            showVoiceUnavailable(item, localeTag)
            finishCurrent(preserveNotification = true)
            return
        }

        val selectedVoiceName = settings["voiceName"]?.toString().orEmpty()
        val selectedVoice = matchingVoices.firstOrNull { it.name == selectedVoiceName }
        val defaultVoice = tts.defaultVoice?.takeIf { candidate ->
            matchingVoices.any { it.name == candidate.name }
        }
        val voice = selectedVoice ?: defaultVoice
            ?: matchingVoices.maxByOrNull { it.quality }
        try {
            if (voice != null) {
                tts.voice = voice
            } else {
                val result = tts.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    showVoiceUnavailable(item, localeTag)
                    finishCurrent(preserveNotification = true)
                    return
                }
            }
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val manager = audioManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager != null) {
                focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attributes)
                    .setOnAudioFocusChangeListener { }
                    .build()
                manager.requestAudioFocus(focusRequest!!)
            }
            tts.setAudioAttributes(attributes)
            tts.setSpeechRate((settings["speechRate"] as? Number)?.toFloat() ?: 0.92f)
            tts.setPitch((settings["speechPitch"] as? Number)?.toFloat() ?: 1f)
            repeatIndex = 0
            speakNextRepeat(item, settings)
        } catch (_: Exception) {
            showEngineFailure(item)
            finishCurrent(preserveNotification = true)
        }
    }

    private fun speakNextRepeat(item: SpeechItem, settings: Map<String, Any>) {
        if (current?.id != item.id) return
        val repeatCount = if (item.isPreview) 1 else {
            (settings["repeatCount"] as? Number)?.toInt()?.coerceIn(1, 3) ?: 1
        }
        if (repeatIndex >= repeatCount) {
            finishCurrent()
            return
        }
        repeatIndex += 1
        val volume = (settings["speechVolume"] as? Number)?.toFloat()?.coerceIn(0f, 1f) ?: 1f
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume)
        }
        val utteranceId = "${item.id}-$repeatIndex"
        currentUtteranceId = utteranceId
        val result = textToSpeech?.speak(
            item.text,
            TextToSpeech.QUEUE_FLUSH,
            params,
            utteranceId,
        ) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) onSpeechError()
    }

    private fun onSpeechDone() {
        val item = current ?: return
        val settings = ReminderDatabase.get(this).getSettings()
        val repeatCount = if (item.isPreview) 1 else {
            (settings["repeatCount"] as? Number)?.toInt()?.coerceIn(1, 3) ?: 1
        }
        if (repeatIndex < repeatCount) {
            mainHandler.postDelayed(
                { speakNextRepeat(item, settings) },
                REPEAT_PAUSE_MS,
            )
        } else {
            finishCurrent()
        }
    }

    private fun onSpeechError() {
        current?.let {
            showEngineFailure(it)
        }
        finishCurrent(preserveNotification = true)
    }

    private fun showVoiceUnavailable(item: SpeechItem, localeTag: String) {
        if (item.isPreview) {
            ReminderNotifications.showPreview(
                this,
                getString(R.string.tts_voice_unavailable, localeTag),
            )
        } else {
            ReminderNotifications.showSpeechUnavailable(this, item.id, item.title, localeTag)
        }
    }

    private fun showEngineFailure(item: SpeechItem) {
        if (item.isPreview) {
            ReminderNotifications.showPreview(this, getString(R.string.tts_failure))
        } else {
            ReminderNotifications.showEngineFailure(this, item.id, item.title)
        }
    }

    private fun failQueuedSpeech() {
        current?.let(::showEngineFailure)
        queue.forEach(::showEngineFailure)
        queue.clear()
        current = null
        currentUtteranceId = null
        stopAfterQueue()
    }

    private fun finishCurrent(preserveNotification: Boolean = false) {
        val finished = current
        current = null
        currentUtteranceId = null
        if (!preserveNotification) {
            finished?.let {
                if (it.isPreview) {
                    ReminderNotifications.cancelPreview(this)
                } else {
                    ReminderNotifications.showReminder(this, it.id, it.title, it.text)
                }
            }
        }
        abandonAudioFocus()
        val next = if (queue.isEmpty()) null else queue.removeFirst()
        if (next != null) {
            current = next
            enterForeground(next)
            if (engineReady) speakCurrent()
        } else {
            stopAfterQueue()
        }
    }

    private fun remove(id: String) {
        mainHandler.post {
            queue.removeAll { it.id == id }
            if (current?.id == id) {
                textToSpeech?.stop()
                current = null
                currentUtteranceId = null
                val next = if (queue.isEmpty()) null else queue.removeFirst()
                if (next != null) {
                    current = next
                    enterForeground(next)
                    if (engineReady) speakCurrent()
                } else {
                    stopAfterQueue()
                }
            }
        }
    }

    private fun stopAfterQueue() {
        abandonAudioFocus()
        releaseWakeLock()
        if (foreground) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_DETACH)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(false)
            }
            foreground = false
        }
        stopSelf()
    }

    private fun acquireWakeLock() {
        try {
            wakeLock?.takeIf { !it.isHeld }?.acquire(MAX_WAKE_LOCK_MS)
        } catch (_: Exception) {
            // The foreground service remains active even if the vendor denies a wake lock.
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.takeIf { it.isHeld }?.release()
        } catch (_: Exception) {
            // The lock may already have timed out.
        }
    }

    private fun abandonAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { manager.abandonAudioFocusRequest(it) }
            focusRequest = null
        } else {
            @Suppress("DEPRECATION")
            manager.abandonAudioFocus(null)
        }
    }

    companion object {
        const val ACTION_SPEAK = "com.voicelife.reminder.action.SPEAK"
        const val ACTION_PREVIEW = "com.voicelife.reminder.action.PREVIEW"
        const val EXTRA_REMINDER_ID = "reminderId"
        const val EXTRA_PREVIEW_TEXT = "previewText"
        private const val PREVIEW_ID = "__voice_life_preview__"
        private const val MAX_WAKE_LOCK_MS = 10 * 60 * 1000L
        private const val REPEAT_PAUSE_MS = 850L

        @Volatile
        private var instance: ReminderSpeechService? = null

        fun removeIfRunning(id: String) {
            instance?.remove(id)
        }
    }
}
